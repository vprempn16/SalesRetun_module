<?php
chdir("../");
if (!file_exists("vendor/autoload.php")) {
	echo "Please install composer dependencies.";
	exit;
}
//Overrides GetRelatedList : used to get related query
//TODO : Eliminate below hacking solution
include_once 'config.php';
require_once 'vendor/autoload.php';
include_once 'include/Webservices/Relation.php';

include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

$Vtiger_Utils_Log = true;


class ScriptSalesReturn{
	function __construct(){
		//$this->relatedFieldList();
		//$this->fieldCreation();
		//$this->referenceListEntry();
	}
	function relatedFieldList(){
		global $adb;

		$MODULENAME = 'SalesReturn';
		$tabid = getTabId( $MODULENAME );
		$fieldid = getFieldid( $tabid , 'delivery_note' );
		$result = $adb->pquery( "SELECT * FROM vtiger_fieldmodulerel WHERE fieldid = ? AND module = ? AND relmodule = ?" , [$fieldid, $MODULENAME , 'ITS4YouWHDeliveryNotes'] );
		if( $adb->num_rows( $result ) > 0 ) {
			echo 'ITS4YouWHDeliveryNotes relation already exists<br>';
		} else {
			die;
			$moduleInstance = Vtiger_Module::getInstance($MODULENAME);

			$field = vtiger_field::getinstance ( 'delivery_note' , $moduleInstance );
			$field->setRelatedModules( array( 'ITS4YouWHDeliveryNotes' ) );
			echo 'ITS4YouWHDeliveryNotes module relation created<br>';

		}

	}

	function fieldCreation(){
		$MODULENAME = 'SalesReturn';
		$moduleInstance = Vtiger_Module::getInstance($MODULENAME);
		if ($moduleInstance)
		{
			echo "Module already present - choose a different name.";
			// Field Setup
			$block = Vtiger_Block::getInstance('LBL_SR_INFORMATION',$moduleInstance);

			$field3 = Vtiger_Field::getInstance('tax1', $moduleInstance);
			if(!$field3){
				$field3 = new Vtiger_Field();
				$field3->name = "tax1";
				$field3->label = "VAT";
				$field3->uitype = 83; 
				$field3->column = $field3->name;
				$field3->columntype = 'VARCHAR(255)';
				$field3->typeofdata = 'V~O';
				$block->addField($field3);
			}

			$field4 = Vtiger_Field::getInstance('hdnSubTotal', $moduleInstance);
			if(!$field4){
				$field4 = new Vtiger_Field();
				$field4->name = "hdnSubTotal";
				$field4->label = "Sub Total";
				$field4->uitype = 72;
				$field4->column = $field4->name;
				$field4->typeofdata = 'N~O';
				$block->addField($field4);
			}

		}
	}
	function referenceListEntry(){
		$MODULENAME = 'StockHistory';

		$moduleInstance = Vtiger_Module::getInstance($MODULENAME);
		if ($moduleInstance)
		{
			echo "Module already present - choose a different name.";
			// Field Setup
			$block = Vtiger_Block::getInstance('LBL__INFORMATION',$moduleInstance);
			$field4 = Vtiger_Field::getInstance('module_name', $moduleInstance);
			$field4->setRelatedModules( array( 'SalesReturn' ) );
		}
	}
}
$ScriptSalesReturn = new ScriptSalesReturn();
